import {put, takeLatest} from 'redux-saga/effects';
import * as Constants from '../constants';
import * as Actions from './action';
import {getSecureData} from '../apil-call';
import {Base_URL} from '../urls';

function* loadusers(action) {
    try {
        //const dataori = yield fetchdataget(Base_URL + action.url);
        const dataori = yield getSecureData(Base_URL + action.url, 'Bearer '.concat(window.sessionStorage.getItem(Constants.ACCESS_TOKEN)));
        yield put(Actions.receiveloadusers(dataori.totalRegisteredUsers));
    } catch (e) {
        yield put(Actions.receiveloadusers([]));
    }
}

function* loadshowroomlist(action) {
    try {
       // console.log("fetchdata from DB in saga layer");
        //const dataori = yield fetchdataget(Base_URL + action.url);
        const dataori = yield getSecureData(Base_URL + action.url, 'Bearer '.concat(window.sessionStorage.getItem(Constants.ACCESS_TOKEN)));
        console.log("Response is showroom---------->" + JSON.stringify(dataori));
        yield put(Actions.receiveloadshowroomlist(dataori.listShowrooms));
    } catch (e) {
        yield put(Actions.receiveloadshowroomlist([]));
    }
}
function* requestAllReports(action) {
    try {
       // console.log("fetchdata from DB in saga layer report List");
        //const dataori = yield fetchdataget(Base_URL + action.url);
        const dataori = yield getSecureData(Base_URL + action.url, 'Bearer '.concat(window.sessionStorage.getItem(Constants.ACCESS_TOKEN)));
        yield put(Actions.allReportsResponse(dataori.reportRequestList));

    } catch (e) {
        yield put(Actions.allReportsResponse([]));
    }
}

function* requestloadSalesPersonlist(action) {
    console.log("requestloadSalesPersonlist"+action)
    try {
    console.log("fetchdata from DB in saga layer ----------------"+Base_URL + action.url);
        //const dataori = yield fetchdataget(Base_URL + action.url);
        const dataori = yield getSecureData(Base_URL + action.url, 'Bearer '.concat(window.sessionStorage.getItem(Constants.ACCESS_TOKEN)));
        console.log("Response is ---------->" + JSON.stringify(dataori.names));
        yield put(Actions.receiveloadsalespersonlist(dataori.names));
    } catch (e) {
        yield put(Actions.receiveloadsalespersonlist([]));
    }
}

export default function* reportSaga() {
    yield takeLatest(Constants.REQUEST_LOAD_USER_DATA, loadusers);
    yield takeLatest(Constants.REQUEST_LOAD_SHOWROOM_LIST_DATA, loadshowroomlist);
    yield takeLatest(Constants.REQUEST_ALL_REPORTS, requestAllReports);
    yield takeLatest(Constants.REQUEST_LOAD_SALESPERSON_LIST_DATA, requestloadSalesPersonlist);
}
