import React, { Component } from 'react';
import { PropTypes } from 'prop-types';
import { connect } from 'react-redux';
import { requestloadusers } from './action';
import Header from '../components/header';
import Footer from '../components/footer';
import Sidemenu from '../components/sidemenu_admin';
import DatePicker from "react-datepicker";
import { requestloadshowroomlist, requestAllReports, requestloadSalesPersonlist, } from './action';
import _ from "lodash";
import { CSVLink, CSVDownload } from 'react-csv';
import queryString from 'query-string';
import "react-datepicker/dist/react-datepicker.css";


class Report extends Component {
    constructor(props) {
        super(props);
        this.state = {
            startDate: '',
            startDate: '',
            endDate: '',
            bloodGroup: '',
            showroom: '',
            salesperson: "",
            isShowroomLoaded: false,
            selectedShowroom: '',
            reportlist: "",
            reports: "",
            data: [],
            filter: [],
            status: '',
            d1: '',
            d2: '',
            date: [],
            fvalue: {},
            filtering: "",
            page: "",
            users: '',
        };
        this.handleChangeStartDate = this.handleChangeStartDate.bind(this);
        this.handleChangeEndDate = this.handleChangeEndDate.bind(this);
        this.handleShowroomSelectChange = this.handleShowroomSelectChange.bind(this);
    }

    handleChangeStartDate = (date) => {
        let dayparam = (date.getDate() < 10) ? '0' + date.getDate() : date.getDate();
        let dayparams = (date.getDate() < 10) ? '0' + date.getDate() : date.getDate();
        let monthparam = (date.getMonth() < 9) ? (1 + date.getMonth()) : (1 + date.getMonth());
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Octr", "Nov", "Dec"];
        let dateparam = dayparam + '-' + monthNames[date.getMonth()] + '-' + date.getFullYear();
        var days = dayparam;
        this.state.d1 = (date.getFullYear() + "," + monthparam + "," + days);
        console.log(this.state.d1);
        console.log(new Date(this.state.d1));
        console.log(new Date(this.state.d1).toISOString().split('T')[0]);
        this.setState({
            startDate: dateparam,
        });
        console.log(dateparam);

        this.setState({
            filtering: '',
        });
        this.setState({
            bloodGroup: "",
            status:""
        });
        this.setState({
            endDate: "",
        });
        this.filter('requestDate', dateparam);
        console.log('finaltesting' + this.state.filtering)

    };

    handleChangeEndDate = (date) => {
        let dayparam = (date.getDate() < 10) ? '0' + date.getDate() : date.getDate();
        let dayparams = (date.getDate() < 10) ? date.getDate() : date.getDate();
        let monthparam = (date.getMonth() < 9) ? (1 + date.getMonth()) : (1 + date.getMonth());
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Octr", "Nov", "Dec"];
        let dateparam = dayparam + '-' + monthNames[date.getMonth()] + '-' + date.getFullYear();
        var days = dayparam;
        this.state.d2 = (date.getFullYear() + "," + monthparam + "," + days);
        console.log(this.state.d2);
        console.log(dateparam);

        this.setState({
            endDate: dateparam,
        });
        this.setState({
            bloodGroup: "",
            status:""
        });
        
        this.date()
    }


    date = () => {
        console.log(this.state.d1 + "3333333333" + this.state.d2);
        var now = new Date(this.state.d2);
        var daysOfYear = [];
        for (var d = new Date(this.state.d1); d <= now; d.setDate(d.getDate() + 1)) {
            console.log(d)
            var today = new Date(d).toLocaleDateString();
            console.log(today);
            var dd = today.split("/");
            console.log("date" + dd);
            const monthNames = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            var m = Number(dd[0]);
            console.log(m);
            console.log(monthNames[m]);
            var xx = monthNames[m];
            console.log(xx);
            if (dd[1] <= 9) {
                var date = '0' + dd[1] + "-" + xx + "-" + dd[2];
                console.log("-------------" + date);
            } else {
                var date = dd[1] + "-" + xx + "-" + dd[2];
                console.log("555555555555" + date);
            }


            daysOfYear.push(date);
        }
        this.state.date = daysOfYear;
        console.log("daysOfYear" + this.state.date);
        console.log("daysOfYear length     " + this.state.date.length);
        console.log("daysOfYear" + daysOfYear);
        const reports = this.state.reportlist;
        {
            var da = {};
            var ta = [];
            var ks = [];

            for (var i = 0; i <= (this.state.date.length); i++) {
                console.log('testingcode' + this.state.date[i]);
                da["requestDate"] = this.state.date[i];
                console.log('testing1' + JSON.stringify(da));
                ks = _.filter(reports, da);
                console.log('testing2' + JSON.stringify(ks));
                var ss = ta.concat(ks);
                ta = ss;
                this.state.filtering = ta;
            }
        }
        this.setState({ reports: this.state.filtering });

        this.setState({ fvalue: {} });
    }

    handleSelectChangeBlood = (bloodGroup) => {
        this.setState({ bloodGroup: bloodGroup });
    }
    handleSelectChangeStatus = (status) => {
        this.setState({ status: status })
    };
    handleShowroomSelectChange = (selectedOption) => {
        this.setState({ showroom: selectedOption })
    };

    componentDidMount() {
        let url = this.props.location.search;
        let params = queryString.parse(url);
        console.log("params.userName" + params.userName);
        this.setState({
            page: params.userName,
        })
        this.props.requestAllReports();
        this.props.requestloadusers();

    }
    componentDidUpdate() {

        console.log("filter" + JSON.stringify(this.state.reports));
        console.log("datefilter" + JSON.stringify(this.state.filtering));


    }
    componentWillReceiveProps(nextProps) {
    }
    static getDerivedStateFromProps(nextProps, prevState) {

        if (nextProps.reports !== prevState.reportlist) {
            return { reports: nextProps.reports, reportlist: nextProps.reports };
        }
        else return null;
    }
    navigate = (url) => {
        this.props.history.push(url);
    }





    handleChangeBlood = (event) => {
        const { name, value } = event.target;
        this.state.bloodGroup = value;
        this.filter('bloodGroup', value);
    };

    handleChangeStatus = (event) => {
        const { name, value } = event.target;
        this.state.status = value;
        this.filter('status', value);
    };

    date1 = () => {
        var reports = this.state.reports;
        var date = reports.filter(({ requestDate }) => { return _.lte(requestDate, this.state.startDate) });
        console.log(JSON.stringify(date));
        var date2 = reports.filter(({ requestDate }) => { return _.lte(requestDate, this.state.startDate) });
        console.log(JSON.stringify(date2));

    }

    filter = (event, value) => {
       console.log("000000000000000" + this.state.filtering);
               this.state.reports = _.cloneDeep(this.state.reports);

        if (this.state.filtering !== "") {
            console.log(this.state.filtering);
            console.log("1st");
            const reports = this.state.filtering;

            var ff = (event + ":this.state." + event)
            console.log(ff)
            this.state.fvalue[event] = value;
            if (value === ("All" || "")) {
                delete this.state.fvalue[event];
            }
            console.log(this.state.fvalue);
            this.setState({ reports: _.filter(reports, this.state.fvalue) });
            console.log("filter" + JSON.stringify(this.state.reports));
        } else {
            console.log("2st")
            const reports = this.state.reportlist;

            var ff = (event + ":this.state." + event)
            this.state.fvalue[event] = value;
            if (value === ("All" || "")) {
                delete this.state.fvalue[event];
            }
            this.setState({ reports: _.filter(reports, this.state.fvalue) });
            console.log("filter" + JSON.stringify(this.state.reports));
        }

    }
    openDatepicker = () => this._calendar.setOpen(true);

    filterclear=()=>{
        window.location.reload();
    }


    render() {
        const { startDate, endDate, bloodGroup, showroom, salesPerson, data, status, users, date } = this.state;


        let data1 = [];
        if (this.props.reports !== undefined && this.props.reports !== null) {
            for (var i = 1; i <= (this.props.reports.length); i++) {
                {
                    this.props.reports && this.props.reports.length > 0 && _.orderBy(this.state.reports, ["ticket"], ["desc"]).map((reports, i) => (
                        data1[i] = {
                            Token: reports.token,
                            Date: reports.requestDate,
                            BloodGroup: reports.bloodGroup,
                            Requestor: reports.requestor,
                            Status: reports.status,
                            Reason: reports.reason,
                        }
                    ))
                }
                this.state.data = data1;

            }



        }



        return (
            <div className="page-container" style={{ paddingLeft: "0px" }}>
                <Header navigate={(url) => this.navigate(this.state.page)} />
                <main className="main-content bgc-grey-100">
                    <div id="mainContent">
                        <div id="mainContent">
                            <div className="row">
                                <Sidemenu navigate={(url) => this.navigate(url)} selected="report" />
                                <div className="col-md-10">
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-2" style={{ marginRight: '-30px' }}>
                                                <label htmlFor="cancelreason">Start Date</label>
                                                <div className="dateclass" style={{ width: '120px', }} >
                                                    <DatePicker
                                                        name="startDate"
                                                        value={startDate}
                                                        id="startDate"
                                                        onChange={this.handleChangeStartDate}
                                                    />


                                                </div>
                                            </div>
                                            <div className="col-md-2" style={{ marginRight: '-30px' }}>
                                                <label htmlFor="cancelreason">End Date</label>
                                                <div className="dateclass" style={{ width: '120px' }}>
                                                    <DatePicker
                                                        name="endDate"
                                                        value={endDate}
                                                        id="endDate"
                                                        onChange={this.handleChangeEndDate}
                                                        minDate={new Date(startDate)}
                                                        maxDate={new Date()}
                                                    />
                                                </div>
                                            </div>


                                            <div className="col-md-2">
                                                <label htmlFor="bloodGroup" style={{ width: '90px' }}>Blood Group</label>
                                                <select className="form-control" name="bloodGroup" value={bloodGroup} onChange={this.handleChangeBlood}  >
                                                    <option value="All">All</option>
                                                    <option value="A +ve">A +ve</option>
                                                    <option value="A -ve">A -ve</option>
                                                    <option value="A1 +ve">A1 +ve</option>
                                                    <option value="A1 -ve">A1 -ve</option>
                                                    <option value="B +ve">B +ve</option>
                                                    <option value="B -ve">B -ve</option>
                                                    <option value="O +ve">O +ve</option>
                                                    <option value="O -ve">O -ve</option>
                                                    <option value="AB +ve">AB +ve</option>
                                                    <option value="AB -ve">AB -ve</option>
                                                    <option value="A2 +ve">A2 +ve</option>
                                                    <option value="A2 -ve">A2 -ve</option>
                                                    <option value="A2B +ve">A2B +ve</option>
                                                    <option value="A2B -ve">A2B -ve</option>
                                                    <option value="A1B +ve">A1B +ve</option>
                                                    <option value="A1B -ve">A1B -ve</option>
                                                    <option value="Bombay Blood Group">Bombay Blood Group</option>
                                                </select>
                                            </div>

                                            <div className="col-md-2" style={{ width: '120px' }}>
                                                <label htmlFor="status">Status</label>
                                                <select className="form-control" name="status" value={status} onChange={this.handleChangeStatus} >
                                                    <option value="All">All</option>
                                                    <option value="New">New</option>
                                                    <option value="In Progress">In Progress</option>
                                                    <option value="Closed">Closed</option>
                                                    <option value="Cancelled">Cancelled</option>
                                                </select>
                                            </div>

                                            <div className="col-md-2" style={{ width: '200px' }}>
                                                <label htmlFor="users" style={{ width: '200px' }}>Total Registered Users</label>
                                                <input type="text"
                                                    className="form-control" id="users"
                                                    name="users" value={this.props.users} disabled={true}

                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-2" style={{ marginRight: '-30px' }}>
                                        <div >
                                            <button type="button" className="btn btn-primary" style={{ marginTop: '20px',backgroundColor:'#f44336' }} ><CSVLink data={this.state.data} filename={"downlaod.csv"}><font color="white">Export to CSV</font></CSVLink> </button>
                                        </div>
                                    </div>  
                                    <div className="col-md-2" style={{ marginRight: '-30px' }}>
                                        <div >
                                            <button type="button" className="btn btn-primary" style={{ marginTop: '20px',backgroundColor:'#f44336' }} onClick={this.filterclear} >Clear</button>
                                        </div>
                                    </div>  
                                     </div> </div>

                                    <div className="col-md-2" style={{ marginTop: '20px' }} ></div>

                                    <div className="row" >

                                        <div className="bgc-white bd bdrs-2 p-20" style={{ width: '100%' }} >
                                            <h4 className="c-grey-900 col-md-10">Report Details</h4>
                                            <div className="row">
                                                <table className="table table-hover" >


                                                    <thead  >

                                                        <tr  >
                                                            <th scope="col">Token</th>
                                                            <th scope="col">Date</th>
                                                            <th scope="col">Blood Group</th>
                                                            <th scope="col">Requestor</th>
                                                            <th scope="col">Status</th>
                                                            <th scope="col">Reason</th>
                                                            <th scope="col">Donated By</th>
                                                            <th scope="col"> Donor Mobile</th>
                                                            <th scope="col">Email</th>
                                                            <th scope="col">District and Area</th>

                                                        </tr>

                                                    </thead>


                                                    <tbody>
                                                        {
                                                            this.props.reports && this.props.reports.length > 0 && _.orderBy(this.state.reports, ["ticket"], ["desc"]).map((reports, reportskey) => (
                                                                <tr key={reportskey}>
                                                                    <th scope="row">{reports.token}</th>

                                                                    <td > {reports.requestDate}</td>
                                                                    <td>{reports.bloodGroup}</td>

                                                                    <td>{reports.requestor}</td>
                                                                    <td>{reports.status}</td>
                                                                    <td>{reports.reason}</td>
                                                                    <td>{reports.donatedBy}</td>
                                                                    <td>{reports.donorMobile}</td>
                                                                    <td>{reports.email}</td>
                                                                    <td>{reports.districtAndArea}</td>

                                                                </tr>
                                                            ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <Footer />
            </div>
        )
    }
}
Report.propTypes = {
    requestloaddistrict: PropTypes.func,
    requestloadshowroomlist: PropTypes.func,
    requestAllReports: PropTypes.func,
    reports: PropTypes.func,
    reportlist: PropTypes.func,
    requestloadSalesPersonlist: PropTypes.func,
    users: PropTypes.func,
    requestloadusers: PropTypes.func,




};

const mapStateToProps = state => {
    console.debug(state, 'state');
    return {
        userlist: state.userreducer.userlist,
        showroomlist: state.reportReducer.showroomlist,
        reports: state.reportReducer.reports,
        salesPersonlist: state.reportReducer.salesPersonlist,
        users: state.reportReducer.users,


    };
};

const mapDispatchToProps = dispatch => ({
    requestloadusers: state => dispatch(requestloadusers(state)),
    requestloadshowroomlist: showroom => dispatch(requestloadshowroomlist(showroom)),
    requestAllReports: state => dispatch(requestAllReports(state)),
    requestloadSalesPersonlist: salesPerson => dispatch(requestloadSalesPersonlist(salesPerson)),


});

export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(Report);
