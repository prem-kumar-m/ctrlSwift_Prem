import * as Constants from '../constants';

export const requestloadusers = state => ({
    type: Constants.REQUEST_LOAD_USER_DATA,
    url: Constants.API_URLS.LOAD_USER_URL,
    state,
});

export const receiveloadusers = users => ({
    type: Constants.RECEIVE_LOAD_USER_DATA,
    users,
});

export const requestloadshowroomlist = showroom =>
    ({

        type: Constants.REQUEST_LOAD_SHOWROOM_LIST_DATA,
        url: Constants.API_URLS.LIST_SHOWROOM_URL,
        showroom,
    });


export const receiveloadshowroomlist = showroomlist => ({
    type: Constants.RECEIVE_LOAD_SHOWROOM_LIST_DATA,
    showroomlist,
});
export const requestAllReports = () => ({
    type: Constants.REQUEST_ALL_REPORTS,
    url: Constants.API_URLS.LIST_REPORTS_URL,

});

export const allReportsResponse = reports => ({
    type: Constants.ALL_REPORTS_RESPONSE,
    reports,
});

export const requestloadSalesPersonlist = salesPerosn =>
    ({
        type: Constants.REQUEST_LOAD_SALESPERSON_LIST_DATA,
        url: Constants.API_URLS.LIST_SALESPERSON_URL,
        salesPerosn,
    });


export const receiveloadsalespersonlist = salesPersonlist => ({
    type: Constants.RECEIVE_LOAD_SALESPERSON_LIST_DATA,
    salesPersonlist,
});