import * as Constants from '../../constants'; 
 
 export const validateOtpCustomerData = state => ({
  type: Constants.VALIDATE_OTP_CUSTOMER_DATE,
  url: Constants.API_URLS. OTP_CUSTOMER_SUCCESS_URL,
   state,
 });

export const forgotOtpCustomer = (getmail, otp) => ({
  type: Constants.FORGOTPASSWORD_CUSTOMER_VERIFY_OTP,       //this will match with your saga
  url: Constants.API_URLS.VERIFY_CUSTOMER_OTP_URL,
  getmail,
  otp,
});

export const forgotOtpCustomerResponse = isValidatdOtpSuccess => ( {
  type: Constants.FORGOTPASSWORD_CUSTOMER_VERIFY_OTP_RESPONSE,
  isValidatdOtpSuccess,
}
);


export const resendOtpCustomer = (getmail, otp) => ({ 
  type: Constants.LOGIN_RESENDOTP_CUSTOMER_VERIFY,       //this will match with your saga
  url: Constants.API_URLS.LOGIN_RESENDOTP_CUSTOMER_URL,
  getmail,
  otp,
});

export const resendOtpCustomerResponse = resendOtpSuccess => ( {
  type: Constants.LOGIN_RESENDOTP_CUSTOMER_RESPONSE,
  resendOtpSuccess,
}
);



