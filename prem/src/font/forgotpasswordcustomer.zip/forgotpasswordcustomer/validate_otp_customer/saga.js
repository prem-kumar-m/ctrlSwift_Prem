import {put, takeLatest} from 'redux-saga/effects';
import * as Constants from '../../constants';
import * as Actions from './action';
import {fetchdataget,postdata} from '../../apil-call'; 
import {Base_URL} from '../../urls';


function* resendOtpCustomer(action) {
  console.log("action"+JSON.stringify(action));
  try{
     const responseData = yield postdata(Base_URL + Constants.API_URLS. LOGIN_RESENDOTP_CUSTOMER_URL, 
    {
       'email' : action.getmail,
    });
    console.log("responseData"+JSON.stringify(responseData))
    if(responseData.status === 200 && responseData.data.success !== "undefined" && responseData.data.success === true) {
      yield put(Actions.resendOtpCustomerResponse(responseData.data));
    }
    else if( responseData.data.success !== "undefined" && responseData.data.success === false && responseData.data.message === "E105" ){
      const errorMessage = {'success' : false, 'message' : 'You are already press resend two times. Please Login Again.'};
      yield put(Actions.resendOtpCustomerResponse(errorMessage));
    }
  } catch (e) {
    const errorMessage = {'success' : false, 'message' : 'Unable to get your request, please try again'};
    yield put(Actions.resendOtpCustomerResponse(errorMessage));
  }
}


function* forgotOtpCustomer(action) {
  console.log("action"+JSON.stringify(action));
  try{
     const responseData = yield postdata(Base_URL + Constants.API_URLS.VERIFY_CUSTOMER_OTP_URL, 
    {
       'email' : action.getmail,
       'otp' : action.otp,
    });
    console.log("responseData"+JSON.stringify(responseData))
    if(responseData.status === 200 && responseData.data.success !== "undefined" && responseData.data.success === true) {
      yield put(Actions.forgotOtpCustomerResponse(responseData.data));
    }
    else if( responseData.data.success !== "undefined" && responseData.data.success === false && responseData.data.message === "E103") {
      const errorMessage = {'success' : false, 'message' : 'Invalid OTP.Please provide the valide OTP '};
      yield put(Actions.forgotOtpCustomerResponse(errorMessage));
    }
  } catch (e) {
    const errorMessage = {'success' : false, 'message' : 'Could not get the OTP. Plz try again.'};
    yield put(Actions.forgotOtpCustomerResponse(errorMessage));
  }
}
export default function* forgotOtpCustomerSage(){

    yield takeLatest(Constants.FORGOTPASSWORD_CUSTOMER_VERIFY_OTP, forgotOtpCustomer);
    yield takeLatest(Constants.LOGIN_RESENDOTP_CUSTOMER_VERIFY, resendOtpCustomer);
}
  