import * as Constants from '../../constants';
import {any} from "prop-types"; 

export default (
  state = {},
    {type, getmail = '', otp='', isValidatdOtpSuccess = any, resendOtpSuccess =any},
) => {
  switch (type) {
    case Constants.RECEIVE_LOAD_DISTRICT_DATA: { 
      const statenew = {...state};
      statenew.getmail = getmail;
      statenew.otp = otp;
      return statenew;
    }

      case Constants.FORGOTPASSWORD_CUSTOMER_VERIFY_OTP_RESPONSE: {
          const statenew = {...state};
          
          statenew.isValidatdOtpSuccess = isValidatdOtpSuccess;
        
          return statenew;
      }

      case Constants.LOGIN_RESENDOTP_CUSTOMER_RESPONSE: { 
        
        const statenew = {...state};
        statenew.resendOtpSuccess = resendOtpSuccess;
        return statenew;
      }

    default:
      return state;
  }
};
