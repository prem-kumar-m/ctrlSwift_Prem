 import * as Constants from '../../constants';
import {any} from "prop-types"; 

export default (
  state = {},
    {type, getmail = '', isVerifySuccess = any},
) => {
  switch (type) { 
    case Constants.RECEIVE_FORGOTPASSWORD: {
      const statenew = {...state};
      statenew.getmail = getmail;
      return statenew;
    }

      case Constants.FORGOTPASSWORD_CUSTOMER_RESPONSE: {
          const statenew = {...state};
          statenew.isVerifySuccess = isVerifySuccess;
          return statenew;
      }
    default:
      return state;
  }
};