import {put, takeLatest} from 'redux-saga/effects';
import * as Constants from '../../constants';
import * as Actions from './action';
import {fetchdataget,postdata} from '../../apil-call';
import {Base_URL} from '../../urls';

function* verifyEmailCustomer(action) {
  console.log("action"+JSON.stringify(action));
  try{
    const responseData = yield postdata(Base_URL +Constants.API_URLS.FORGOTPASSWORD_CUSTOMER_URL ,
      {
        "email": action.getmail,
      });
      console.log("responseData"+JSON.stringify(responseData));
      if(responseData.status === 200 && responseData.data.success !== "undefined" && responseData.data.success === true) {
        yield put(Actions.verifyEmailCustomerResponse(responseData.data));
    }
    else if( responseData.data.success !== "undefined" && responseData.data.success === false && responseData.data.message === "E104" ){
      const errorMessage = {'success' : false, 'message' : 'Please provide The Registered Email Address'};
      yield put(Actions.verifyEmailCustomerResponse(errorMessage));
    } else if( responseData.data.success !== "undefined" && responseData.data.success === false && responseData.data.message === "E120" ){
      const errorMessage = {'success' : false, 'message' : 'You are not seems to be Admin. Please check the mail.'};
      yield put(Actions.verifyEmailCustomerResponse(errorMessage));
    }
  } catch (e) {
    const errorMessage = {'success' : false, 'message' : 'Technical issues, Please try again'};
    yield put(Actions.verifyEmailCustomerResponse(errorMessage));
  }
}
export default function* getmailcustomerSaga() {
    yield takeLatest(Constants.FORGOTPASSWORD_CUSTOMER_DATA, verifyEmailCustomer);
}
