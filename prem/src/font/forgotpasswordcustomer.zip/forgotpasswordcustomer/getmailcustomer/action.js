import * as Constants from '../../constants';

 
 export const verifyEmailCustomer = (getmail) => ({
   type: Constants.FORGOTPASSWORD_CUSTOMER_DATA,
   url: Constants.API_URLS.FORGOTPASSWORD_CUSTOMER_URL, 
   getmail,
 });



export const verifyEmailCustomerResponse = isVerifySuccess => ( {
  type: Constants.FORGOTPASSWORD_CUSTOMER_RESPONSE,
  isVerifySuccess,
}
);
