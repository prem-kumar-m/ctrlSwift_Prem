import React from "react";
import "./HomePage.scss";
import backgroundImage from "../../images/header-bg.jpg";
import backgroundImage1 from "../../images/header-bg-h2.jpg";
import backgroundImage2 from "../../images/header-bg-h3.jpg";
import backgroundImage3 from "../../images/about1.jpg";
import backgroundImage4 from "../../images/about2.jpg";
import backgroundImage5 from "../../images/video-bg.jpg";
import backgroundImage6 from "../../images/s3.jpg";
import backgroundImage7 from "../../images/s1.jpg";
import backgroundImage8 from "../../images/s4.jpg";
import backgroundImage9 from "../../images/diagram-02.jpg";
import backgroundImage10 from "../../images/l1.png";
import backgroundImage11 from "../../images/l2.png";
import backgroundImage12 from "../../images/l3.png";
import backgroundImage13 from "../../images/l4.png";
import backgroundImage14 from "../../images/l5.png";
import backgroundImage15 from "../../images/l6.png";
import backgroundImage16 from "../../images/l7.png";
import backgroundImage17 from "../../images/l8.png";
import backgroundImage18 from "../../images/l9.png";
import backgroundImage19 from "../../images/20.png";
import backgroundImage25 from "../../images/demovideo.mp4";
import SplitterLayout from 'react-splitter-layout';
import 'react-splitter-layout/lib/index.css';
import Header from "../../components/header/Header";
import Footer from "../../components/footer/Footer";
import Swal from 'sweetalert2';
import { Link } from 'react-router-dom';
import { Redirect } from 'react-router'

import {PropTypes} from 'prop-types';
import {connect} from 'react-redux';

import queryString from 'query-string'
import { newPasswordCustomer } from './action';


import "../../css/bootstrap/bootstrap.css";
import "../../css/main.css";
import "../../css/font-awesome.min.css";
import "../../css/linearicons.css";
import"../../css/nice-select.css";
import "../../css/animate.min.css";
import "../../css/magnific-popup.css";

import { useHistory } from 'react-router-dom';

import ReactPlayer from 'react-player'
import {
  MDBCard,
  MDBCardTitle,
  MDBBtn,
  MDBRow,
  MDBCol,
  MDBIcon
} from "mdbreact";

import { Container, Row, Col, Form, Button,Modal, } from "react-bootstrap";
import Carousel from 'react-bootstrap/Carousel'
 
class resetPasswordCustomer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
        username: '',
        nameError: '',
        email: '',
        emailError:'',
        message:'',
        submitted: false,
        isLoginSuccess: false,
        isReadyToRedirect: false,
        emailError:'',
        navigate:'',
        showmailModal:'false',
        getmail:'',
        page:'',
        isVerifySuccess: false,
        newpassword:'',
        newpasswordError:'',
        confirmpassword:'',
        confirmpasswordError:'',
        submitted: false,
        isnewPasswordSuccess: false,
        showpasswordModal:'false'

    };
   // this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this); 
    this.handleNameChange = this.handleNameChange.bind(this);
    this.handleEmailChange = this.handleEmailChange.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleChangeNew = this.handleChangeNew.bind(this);
    this.handleChangeConfirm = this.handleChangeConfirm.bind(this);

}
handleChangeNew = (event) => {
  const {name, value} = event.target;
  this.setState({
      [name]: value
  });
  const re = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d][A-Za-z\d!@#$%^&*()_+]{8,12}$/;

  if (!re.test(value)) {
     
  this.setState({
    newpasswordError : "Password should be atleast (8-12) digits with atleast one alphabet, one number and one symbol",
  });}
 else{
  this.setState({
    newpasswordError : "",
  });
 }
 console.log(this.state.newpasswordError)

};

handleClose = () => {
  this.setState({ showpasswordModal: false })
}


handleChangeConfirm = (event) => {
  const {name, value} = event.target;
  this.setState({
      [name]: value
  });
  const re = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d][A-Za-z\d!@#$%^&*()_+]{8,12}$/;

  if (!re.test(value)) {
     
  this.setState({
      confirmpasswordError : "Password should be atleast (8-12) digits with atleast one alphabet, one number and one special character",
  });}
 else{
  this.setState({
      confirmpasswordError : "",
  });
 }
 console.log(this.state.confirmpasswordError)

};



handleNameChange = (event) => {
  const {name, value} = event.target;
  this.setState({
      [name]: value
  });
  const re = /^[A-Za-z_ ]+$/;

      if (!re.test(value)) {
         
      this.setState({
          nameError : "Invalid name.",
      });}
     else{
      this.setState({
          nameError : "",
      });
     }

};


handleEmailChange = (event) => {
  const {name, value} = event.target;
  this.setState({
      [name]: value 
  });
  const re = /\S+@[A-Za-z]+\.com/;
  const ks = /\S+@[A-Za-z]+\.co.in/;
  if (!re.test(value) && !ks.test(value)) {
      this.setState({

          emailError:"Invalid email" 
      })    
      }else{
 
      this.setState({

          emailError:"" 
      }) 

  }
};

handleChange = (event) => {
  const {name, value} = event.target;
  this.setState({
      [name]: value 
  });
}

handleChanges = (event) => {
  const {name, value} = event.target;
  this.setState({
      [name]: value 
  });
  const re = /\S+@[A-Za-z]+\.com/;
  const ks = /\S+@[A-Za-z]+\.co.in/;
  if (!re.test(value) && !ks.test(value)) {
      this.setState({

          emailError:"Invalid email" 
      })    
      }else{
 
      this.setState({

          emailError:"" 
      }) 

  }
};


handleSubmit(e) {
  e.preventDefault();
  this.setState({submitted: true});
  const {getmail, newpassword,confirmpassword, newpasswordError, confirmpasswordError } = this.state;
  if (( newpassword && confirmpassword && newpassword === confirmpassword &&newpasswordError==='' && confirmpasswordError==='')) {
      this.props.submitnewPasswordCustomer(getmail, newpassword);
      }else if(newpassword && confirmpassword && newpassword !== confirmpassword){
    Swal.fire({
      title: "",
      text: "New password and Confirm Password Is Mismatching",
      icon: 'warning',
      showCancelButton: false,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'OK'
  })
  }
}

handleClose = () => {
  this.setState({ showmailModal: false })



}




componentDidMount() {
  let url = this.props.location.search;
  let params = queryString.parse(url);
  this.setState({getmail: params.getmail});

  this.setState({page: params.page});

}

componentDidUpdate(prevProps, prevState, snapshot) {
  if (this.props.isnewPasswordSuccess !== prevProps.isnewPasswordSuccess) {
      if (this.state.submitted && this.props.isnewPasswordSuccess.success) {
        Swal.fire({
          title: "",
          text: "Password reset is completed",
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK'
      })
      this.props.history.push('/');
      /*.then((res) => {
        if(res.value){
          this.props.history.push('/'+ this.state.page);
        }else if(res.dismiss == 'cancel'){
            console.log('cancel');
        }
    }) */
      } else if (this.state.submitted && !this.props.isnewPasswordSuccess.success) {             
          Swal.fire({
            title: "",
            text: this.props.isnewPasswordSuccess.message,
            icon: 'info',
            showCancelButton: false,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'OK'
        })
      }
      this.setState({submitted : false});
  }
}

  render() {
    //if (this.state.isReadyToRedirect) return <Redirect to={'/forgotOtpCustomer?getmail='+ this.state.getmail+ '&page='+ this.state.page }/>

    const {newpassword,confirmpassword, submitted} = this.state;

   // if (this.state.isReadyToRedirect) return <Redirect to="/requestdemo" />;
  return(
<div >
    <Header/>


<Modal show={this.state.showpasswordModal }   style={{marginTop:200}}backdrop={ 'static' } >
    <Modal.Title style={{textAlign:'center',marginTop:10}}>Enter Password </Modal.Title>
  <Modal.Body>
  <div class="md-form mb-2">
  <i class="fas fa fa-lock prefix grey-text"></i>

    <input type="email" id="defaultForm-email" class="form-control validate" name="newpassword" value={newpassword}  
                         onChange={this.handleChangeNew} />

{submitted && !newpassword &&
                  <div className="help-block" style ={{fontSize:12,color:"red"}}>New Password Is Required</div>
                  }
                   { this.state.newpasswordError !=="" && newpassword && submitted &&
                  <div className="help-block " style ={{fontSize:12,color:"red"}}>{this.state.newpasswordError}</div>
                  }
                
    <label data-error="wrong" data-success="right" for="defaultForm-email">New Password</label>

  </div>
  <div class="md-form mb-2">
  <i class="fas fa fa-lock prefix grey-text"></i>

    <input type="email" id="defaultForm-email" class="form-control validate" name="confirmpassword" value={confirmpassword}  
                         onChange={this.handleChangeConfirm} />

{submitted && !confirmpassword &&
                  <div className="help-block" style ={{fontSize:12,color:"red"}}>Confirm Password Is Required</div>
                  }
                   { this.state.confirmpasswordError !=="" && confirmpassword && submitted &&
                  <div className="help-block " style ={{fontSize:12,color:"red"}}>{this.state.confirmpasswordError}</div>
                  }
                
    <label data-error="wrong" data-success="right" for="defaultForm-email">Confirm Password</label>

  </div>


  
 
                <Row className="justify-content-md-center">

                <Button className="genric-btn primary radius text-uppercase" variant="success"  onClick={this.handleSubmit}  style={{marginTop:10}}>
                Create</Button> 
                </Row>          

                                </Modal.Body>

</Modal>
    <Carousel className="view" style={{marginTop:-10}}>
  <Carousel.Item >
  

  <img src={backgroundImage} className="img-fluid" alt="smaple image"/>
  <div className="mask justify-content-md-center rgba-green-strong">
    <Carousel.Caption >
    <h6 style={{marginBottom:50, fontSize:26}}>Welcome to BALBHAS B1DESK.</h6>
                <h1 class="text"  style={{marginBottom:50, fontSize:32, color:"white"}}>
                  ORDER YOUR
                  </h1> 
                  <h1 style={{marginBottom:50,fontSize:32,color:"white"}}>SERVICE DESK
                  IN
                  <span style={{ color: "#3399cc" }}> 60</span> MINUTES
							</h1>
              <h4 style={{marginBottom:50,color:"white"}}>We provide our services to customers with a view to optimise their
                IT<br></br>
                spend through large scale automation, <br></br>simplification and
                optimisations strategies</h4>

    </Carousel.Caption>
    </div>
  </Carousel.Item>
  
  <Carousel.Item >
  <img src={backgroundImage1} className="img-fluid" alt="smaple image"/>

    <Carousel.Caption>
      <h6 style={{marginBottom:100, fontSize:42, }}>GREATER<br></br>OPERATING<br></br>EFFICIENCY</h6>
      <h4 style={{marginBottom:70,color:"white"}}>thru in-grained “automation” constructs It possesses “Faster ability”
                 
                </h4>    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
  <img src={backgroundImage2} className="img-fluid" alt="smaple image"/>

    <Carousel.Caption>
    <h6 style={{marginBottom:100, fontSize:42}}>HIGHER FIRST<br></br>CALL RESOLUTION<br></br>CAPABITIES</h6>
    <h4 style={{marginBottom:70,color:"white"}}>thru a well defined system of Integrated Knowledge 
    Inventory (centralized instances of SOPs and KEDBs)</h4>
    </Carousel.Caption>
  </Carousel.Item>
</Carousel>


      <Footer />


</div> 
  )
}
}



resetPasswordCustomer.propTypes = {
  newPasswordCustomer: PropTypes.func,
};
const mapStateToProps = state => {
  return {
    isnewPasswordSuccess: state.resetCustomerReducer.isnewPasswordSuccess,
  };
};

const mapDispatchToProps = dispatch => ({
  submitnewPasswordCustomer: (getmail, newpassword) => dispatch(newPasswordCustomer(getmail, newpassword))
});



export default connect(mapStateToProps, mapDispatchToProps)(resetPasswordCustomer);