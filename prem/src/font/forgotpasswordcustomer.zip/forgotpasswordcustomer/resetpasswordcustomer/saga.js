import {put, takeLatest} from 'redux-saga/effects';
import * as Constants from '../../constants';
import * as Actions from './action';
import {fetchdataget,postdata} from '../../apil-call'; 
import {Base_URL} from '../../urls';

function* newPasswordCustomer(action) {
  console.log(Base_URL + Constants.API_URLS.RESETPASSWORD_CUSTOMER_URL, 
    {
       'email' : action.getmail,
       'newPassword' : action.newpassword,
    });
  try{
     const responseData = yield postdata(Base_URL + Constants.API_URLS.RESETPASSWORD_CUSTOMER_URL, 
    {
       'email' : action.getmail,
       'newPassword' : action.newpassword,
    });
    console.log("responseData"+JSON.stringify(responseData))
    if(responseData.status === 200) {
    yield put(Actions.newPasswordCustomerResponse(responseData.data));
    }
    else {
      const errorMessage = {'success' : false, 'message' : 'Could not reset the password, please try again'};
      yield put(Actions.newPasswordCustomerResponse(responseData));
    }
  } catch (e) {
    const errorMessage = {'success' : false, 'message' : 'Could not reset the password, please try again'};
    yield put(Actions.newPasswordCustomerResponse(errorMessage));
  }
}
export default function* resetCustomerSaga(){

    yield takeLatest(Constants.RESETPASSWORD_CUSTOMER_DATA, newPasswordCustomer);
}
  