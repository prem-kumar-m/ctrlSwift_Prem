import * as Constants from '../../constants'; 
 
 export const validateOtpData = state => ({
  type: Constants.VALIDATE_OTP_DATE,
  url: Constants.API_URLS. OTP_SUCCESS_URL,
   state,
 });

export const newPasswordCustomer = (getmail, newpassword) => ({
  type: Constants.RESETPASSWORD_CUSTOMER_DATA,       //this will match with your saga
  url: Constants.API_URLS.RESETPASSWORD_CUSTOMER_URL,
  getmail,
  newpassword,
});

export const newPasswordCustomerResponse = isnewPasswordSuccess => ( {
  type: Constants.RESETPASSWORD_CUSTOMER_RESPONCES,
  isnewPasswordSuccess,
}
);

